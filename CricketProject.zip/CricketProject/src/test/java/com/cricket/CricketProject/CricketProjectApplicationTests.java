package com.cricket.CricketProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricketProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
